/*
Navicat MySQL Data Transfer

Source Server         : turquoise
Source Server Version : 50513
Source Host           : localhost:3306
Source Database       : turquoise

Target Server Type    : MYSQL
Target Server Version : 50513
File Encoding         : 65001

Date: 2011-08-22 23:15:52
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `jobcluster`
-- ----------------------------
DROP TABLE IF EXISTS `jobcluster`;
CREATE TABLE `jobcluster` (
  `clusterID` tinyint(8) NOT NULL,
  `clusterName` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `createdBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createDateTime` datetime DEFAULT NULL,
  `updatedBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`clusterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of jobcluster
-- ----------------------------
INSERT INTO jobcluster VALUES ('1', 'Study Toeic 800', 'A0001', '2011-07-05 21:30:55', 'A0001', '2011-07-05 21:31:04');
INSERT INTO jobcluster VALUES ('5', 'dfcsdsdsds', null, null, null, null);

-- ----------------------------
-- Table structure for `jobcluster2meta`
-- ----------------------------
DROP TABLE IF EXISTS `jobcluster2meta`;
CREATE TABLE `jobcluster2meta` (
  `clusterID` tinyint(8) NOT NULL,
  `jobID` tinyint(8) NOT NULL,
  `leftJobID` tinyint(1) DEFAULT NULL,
  `parentJobID` tinyint(8) DEFAULT NULL,
  `createdBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createDateTime` datetime DEFAULT NULL,
  `updatedBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`clusterID`,`jobID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of jobcluster2meta
-- ----------------------------
INSERT INTO jobcluster2meta VALUES ('1', '1', '1', null, null, null, null, null);
INSERT INTO jobcluster2meta VALUES ('1', '2', '0', '1', null, null, null, null);

-- ----------------------------
-- Table structure for `jobmeta`
-- ----------------------------
DROP TABLE IF EXISTS `jobmeta`;
CREATE TABLE `jobmeta` (
  `jobID` tinyint(8) NOT NULL,
  `jobName` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `createdBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createDateTime` datetime DEFAULT NULL,
  `updatedBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`jobID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of jobmeta
-- ----------------------------
INSERT INTO jobmeta VALUES ('1', 'Read TOEIC800 book', 'A0001', '2011-06-30 22:28:24', 'A0001', '2011-08-22 23:06:54');
INSERT INTO jobmeta VALUES ('2', 'Listen TOEIC800 mp3', 'A0001', '2011-07-03 18:51:02', '', '2011-07-03 23:11:25');
INSERT INTO jobmeta VALUES ('3', 'Make a sentence everyday.', 'A0001', '2011-07-02 12:48:03', '', '2011-07-03 23:24:54');
INSERT INTO jobmeta VALUES ('4', 'AAAAA', 'A0001', '2011-07-09 13:03:49', 'A0001', '2011-07-09 13:03:49');
INSERT INTO jobmeta VALUES ('5', 'fff', '', '2011-07-11 23:41:38', '', '2011-07-11 23:41:38');
INSERT INTO jobmeta VALUES ('6', 'jjjj', '', '2011-07-11 23:42:53', '', '2011-07-11 23:42:53');
INSERT INTO jobmeta VALUES ('8', 'hhh', 'A0001', '2011-07-11 23:43:12', 'A0001', '2011-07-11 23:43:12');

-- ----------------------------
-- Table structure for `processmeta`
-- ----------------------------
DROP TABLE IF EXISTS `processmeta`;
CREATE TABLE `processmeta` (
  `processID` tinyint(8) NOT NULL,
  `processName` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `clusterID` tinyint(8) NOT NULL,
  `firstJobClusterID` tinyint(1) NOT NULL,
  `jobClusterSecquence` tinyint(8) NOT NULL,
  `createdBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createDateTime` datetime DEFAULT NULL,
  `updatedBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`processID`,`clusterID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of processmeta
-- ----------------------------

-- ----------------------------
-- Table structure for `schedule`
-- ----------------------------
DROP TABLE IF EXISTS `schedule`;
CREATE TABLE `schedule` (
  `scheduleID` tinyint(8) NOT NULL,
  `userID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `processID` tinyint(8) NOT NULL,
  `clusterID` tinyint(8) NOT NULL,
  `jobID` tinyint(8) NOT NULL,
  `plannedStartDateTime` datetime DEFAULT NULL,
  `plannedEndDateTime` datetime DEFAULT NULL,
  `actualStartDateTime` datetime DEFAULT NULL,
  `actualEndDateTime` datetime DEFAULT NULL,
  `createdBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `createDateTime` datetime DEFAULT NULL,
  `updatedBy` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updateDateTime` datetime DEFAULT NULL,
  PRIMARY KEY (`scheduleID`,`userID`,`processID`,`clusterID`,`jobID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of schedule
-- ----------------------------

-- ----------------------------
-- Table structure for `userinfo`
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `userID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `middleName` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lastName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `rank` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `job` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `oraganization` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mainJob` bigint(1) DEFAULT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO userinfo VALUES ('A0001', '1', 'yan', null, 'wang', 'employee', 'softwate developer', 'software development department', '1');
INSERT INTO userinfo VALUES ('A0002', null, 'jack', 'w', 'bauer', 'manager', 'guard', 'guard department', '1');
